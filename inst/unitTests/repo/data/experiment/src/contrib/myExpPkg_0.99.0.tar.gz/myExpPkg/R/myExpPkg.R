testFunction <- function() {
    print("Testing myExpPkg.")
}
