testFunction <- function() {
    print("Testing myAnnPkg.")
}
