#' test function
#' 
#' @description Prints the name of the package
#'
#' @examples
#' testFunction()
testFunction <- function() {
    print("Testing myBiocPkg.")
}
